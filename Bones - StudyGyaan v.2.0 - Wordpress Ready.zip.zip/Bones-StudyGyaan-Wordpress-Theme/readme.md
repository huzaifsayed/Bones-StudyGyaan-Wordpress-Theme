# Bones - Wordpress Starter Theme by StudyGyaan.com

Live Demo - https://studygyaan.com/

#### [Download Theme](https://github.com/huzaifsayed/Bones-StudyGyaan-Wordpress-Theme/blob/master/Bones%20-%20StudyGyaan%20v.1.5%20-%20Wordpress%20Ready.zip)

A Lightweight Wordpress Development Theme Developed by StudyGyaan.com

Theme Developed using Bones Wordpress Starter Theme for StudyGyaan.com. Bones is designed to make the life of developers easier. It's built
using HTML5 & has a strong semantic foundation.
It's constantly growing so be sure to check back often if you are a
frequent user. I'm always open to contribution. :)

Designed by Eddie Machado
http://themble.com/bones

License: WTFPL
License URI: http://sam.zoy.org/wtfpl/

#### Helpful Link To Install Sass and Compass
http://thesassway.com/beginner/getting-started-with-sass-and-compass

After Runing Compass - Do Some Changes in ``` /library/scss/breakpoints/_base.scss ``` and see the effects on wordpress theme

#### Command to start compass for development: 
```
compass watch ../theme-name/library/scss
```

#### Helpful links - Tutorial
https://code.tutsplus.com/tutorials/making-a-theme-with-bones-getting-started--wp-26545
https://www.youtube.com/watch?v=-mIU4Enn-dI


#### Theme Ready To install on Wordpress
You can find a .zip file (Bones - StudyGyaan v.1.1 - Wordpress Ready.zip). Just Upload it to Wordpress Directly in Appearance -> Themes -> Add New -> Upload Theme

# Bones-StudyGyaan-Wordpress-Theme
#### This theme is Pure and Not Extra Code/Credit Added. You can use it freely. It's a Premium Fastest Lightweight Wordpress Theme for Free with Zero Error(Check Console in Chrome).
