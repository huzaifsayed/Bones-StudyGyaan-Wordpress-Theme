<?php

// Writing Custom Post Sharer AddtoAny shortocde
function post_sharer_shortcode_sc(){

    echo 'Thanks for reading my posts!';
    }
    // End post_sharer_shortcode()

?>